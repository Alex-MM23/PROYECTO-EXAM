package vacantes.modelo.entidades;

public enum EstatusVacante {
	CREADA,
	CUBIERTA,
	CANCELADA

}
