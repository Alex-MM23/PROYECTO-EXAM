package vacantes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TomasBackendRestVacantesApplication {

	public static void main(String[] args) {
		SpringApplication.run(TomasBackendRestVacantesApplication.class, args);
	}

}
